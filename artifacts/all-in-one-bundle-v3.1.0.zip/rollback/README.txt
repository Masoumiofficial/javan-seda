رول‌بک 3.0.5 -> 3.0.4:
  header.php و style.css را مستقیم جایگزین کنید.
  ab-sidebars-3.0.4.php را با نام inc/ab-sidebars.php در مسیر قالب بگذارید.
