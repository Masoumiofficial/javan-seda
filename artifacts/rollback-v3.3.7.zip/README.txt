javanseda v3.3.7 -> v3.3.6 (بازگشت)
سه فایلِ همین زیپ را با نام‌های زیر جایگزین کنید:
  style.css.3.3.6            -> style.css
  css/ab-glass.css.3.3.6     -> css/ab-glass.css
  inc/songs_post.php.3.3.6   -> inc/songs_post.php
نکته: در v3.3.6 این سه فایلِ PHP/کارت تغییر نکرده بود، پس فایل songs_post.php داخل
زیپِ بازگشت، همان نسخۀ تمیزِ v3.3.5/3.3.6 است (بدون کارآمار).
