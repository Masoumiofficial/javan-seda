نسخۀ 3.3.4 — بازگشت بخش هنرمندان + رفع فلاشِ اسلایدر هنگام رفرش
==============================================================

اگر 3.3.3 را نصب کرده‌اید، فقط یک فایل لازم است:  style.css
   (wp-content/themes/javanseda/style.css)

اگر از نسخه‌های قدیمی‌تر می‌آیید، هشت فایل کامل 3.3.x:
   جایگزین: style.css · single.php · inc/theme-options.php · 404.php · myfunctions.php
            inc/mobiles_header.php
   اضافه : inc/ab-glass.php · css/ab-glass.css

چه عوض شد:
  • ریل خواننده‌ها از همه قاعدۀ من پاک شد (owl خودش تعداد/سایز را تعیین می‌کند، مثل 3.3.2)
  • ریل لمسی فقط برای بخش‌های آهنگِ صفحۀ اصلی (body.home)؛ فهرست‌های بلند دو ستونه
  • بلاک ۲۸: تا پیش از owl init فقط آیند اول چیده می‌شود
    ⇒ «اسلایدر کل صفحه را می‌گیرد» موقع رفرش رفع شد، بدون JS و بدون CLS

کلیدها:
   define('JAVANSEDA_GLASS_UI', false);    // لایۀ شیشه
   define('JAVANSEDA_GLASS_BLUR', false);  // بدون تارکردگی
   define('JAVANSEDA_PERF_DEFER', false);  // init فوری owl (توصیه نمی‌شود؛ رندر اول را بلاک می‌کند)
   تنظیمات قالب → «متن ترانه زیر لینک دانلود»
بازگشت فایل: rollback-v3.3.4.zip (نسخۀ 3.3.3 از style.css و بقیه)
پیش‌نمایش: preview/glass-ui.html — دکمۀ «فلاشِ پیش از init»
