آهنگ‌بان / قالب javanseda — بستهٔ drop-in نسخۀ 3.3.8
================================================================

این پوشه «قالب» نیست؛ پچ است. فایل‌ها را با همان مسیر نسبی داخل
wp-content/themes/javanseda/  بریزید (پوشه‌های fonts/ ، css/ ، inc/ ساخته می‌شوند).

ترتیب پیشنهادی (مهم نیست، ولی همین‌طور راحت‌تر است):
  1) fonts/*.woff2            ← ۵ فایل جدید؛ اگر این‌ها جا بیفتند، فونت‌ها روی woff می‌مانند (سایت سالم)
  2) style.css                ← Version: 3.3.8 + بلوک ۳۲ + مارکر ab-ui-layer
  3) css/ab-ui.css            ← کپی لایه (فقط در حالت «آپدیت قالب مادر» بارگذاری می‌شود)
  4) css/icofont.min.css      ← یک خط: src با woff2
  5) myfunctions.php · inc/*.php · header.php · home.php · single.php · tag.php · ab-mobile-probe.php

پس از آپلود:
  · کش افزونه + Hard Refresh (Ctrl+F5) روی / و یک صفحۀ آهنگ
  · DevTools → Network → Font  ⇒  vazir-fd.woff2  (≈35KB)
  · در صفحۀ آلبوم:  document.querySelectorAll('#audio').length  ⇒  1
  · یک‌بار (برای srcset):  wp media regenerate images --size=thumb2x

اگر بخواهید بخشی را خاموش کنید (wp-config.php، بالای خط «That's all, stop editing!»):
  define( 'JAVANSEDA_SKIP_LINK', false );            // لینک پرش به محتوا
  define( 'JAVANSEDA_PERF_PRELOAD_FONTS', false );   // preload فونت
  define( 'JAVANSEDA_UI_GUARD', false );             // گارد css/ab-ui.css
  define( 'JAVANSEDA_MUSIC_SCHEMA', false );         // JSON-LD آهنگ

⚠  پوشهٔ patches/ را آپلود نکنید؛ فقط آرشیو است (نسخۀ دست‌خورۀ قبلیِ header.php).
⚠  ab-mobile-probe.php اگر کارتان با آن تمام شد، از ریشهٔ هاست حذف شود
   (از این نسخۀ به بعد ?self / ?dl / ?rm / ?save کلید ?k= می‌خواهند).

جزئیات هر تغییر: docs/CHANGES_v3.3.8.md  ·  کارهای دستی: docs/GO-LIVE-CHECKLIST.md
