بازگشت از 3.4.5 به 3.4.4
================================================================================

هر هشت فایل این بسته را در wp-content/themes/javanseda/ با حذف پسوند .3.4.4
بازگردانی کنید (نامشان را عوض کنید):

  style.css.3.4.4                  → style.css
  css/ab-ui.css.3.4.4              → css/ab-ui.css
  css/ab-admin.css.3.4.4           → css/ab-admin.css
  inc/ab-controls.php.3.4.4        → inc/ab-controls.php
  inc/theme-options.php.3.4.4      → inc/theme-options.php
  inc/ab-sidebars.php.3.4.4        → inc/ab-sidebars.php
  myfunctions.php.3.4.4            → myfunctions.php
  single.php.3.4.4                 → single.php

ساده‌تر: لازم نیست چیزی برگردانید —
  · کاور: «کنترل رابط ← کات مربعی کاور» را خاموش کنید (یا «اندازۀ کاور» را روی ۹۰۰ بگذارید)
  · تنظیمات: «کنترل رابط ← پوستۀ همین صفحه» را خاموش کنید
هیچ کلید تازه‌ای در دیتابیس نمی‌ماند؛ فقط دو ردیف در تب «کنترل رابط» بی‌مصرف می‌شود.
