بستهٔ بازگردانی — نسخهٔ 3.1.3
=============================
سریع‌ترین بازگشت (بی‌خطر): فقط فایل‌های افزودۀ ما را حذف کنید — قالب بدون آن‌ها هم کار می‌کند:
  rm wp-content/themes/javanseda/inc/ab-perf.php           (لایۀ «بایتِ سرعت»)
  rm wp-content/themes/javanseda/inc/ab-news-ticker.php    (نوار «اخبار روز»)
  rm wp-content/themes/javanseda/ab-mobile-probe.php       (کاوشگر؛ همیشه پاک شود)
بازگشت دقیق به 3.1.2:
  header.php.3.1.2 / style.css.3.1.2 / myfunctions.php.3.1.2 / home.php.3.1.2 /
  ab-mobile-probe.php.3.1.2 / ab-news-ticker.php.3.1.2 / ab-sidebars-3.1.x-minimal.php
اگر هدر بعد از پچ هنوز مشکل داشت، تمیزترین حالت:
  header.php.original   ← فایل اصلیِ قالب (قبل از همهٔ پچ‌ها) — فقط همین یکی را برگردانید
  برای بقیه کافی است style.css نسخهٔ 3.1.3 روی هاست بماند (بلوک ۲۱ همان کار header.php را می‌کند)
  یا کل drop-in-v3.1.2.zip را اعمال کنید.
نکته: اگر در wp-config.php ثابت‌های JAVANSEDA_NEWS_* / JAVANSEDA_PERF* را تعریف کرده‌اید،
در بازگشت آن خطوط را هم بردارید. بعد از هر بازگشت: Purge All (کش) + Purge CDN.
