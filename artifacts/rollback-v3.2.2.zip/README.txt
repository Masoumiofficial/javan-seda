بازگشت از 3.2.2 به 3.2.1

پنج فایل با پسوند .3.2.1 را (پسوند را بردارید) در wp-content/themes/javanseda جایگزین کنید:
   inc/ab-credits.php · inc/ab-seo.php · inc/ab-perf.php · single.php · style.css
هیچ فایل تازه‌ای در 3.2.2 اضافه نشده، پس چیزی حذف نمی‌شود.

راه بی‌خطرتر (بدون دست‌زدن به فایل‌ها) در wp-config.php:
   define('JAVANSEDA_MUSIC_SCHEMA', false);        // JSON-LD موسیقی خاموش
   define('JAVANSEDA_SEO_OVERRIDE_PLUGIN', true); // گاردِ افزونۀ سئو لغو

نسخۀ کامل 3.2.1 داخل همین فایل: drop-in-v3.2.1.zip
