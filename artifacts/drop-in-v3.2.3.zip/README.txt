نسخۀ 3.2.3 — بازطراحی باکس «شناسنامۀ آهنگ»: افقی و چیپی، کم‌ارتفاع

فقط دو فایل جایگزین شود (هیچ فایل تازه‌ای لازم نیست، هیچ دیتابیسی دست نمی‌خورد):
   inc/ab-credits.php  ->  wp-content/themes/javanseda/inc/ab-credits.php
   style.css           ->  wp-content/themes/javanseda/style.css

پیش‌نمایش محلیِ همان ظاهر (با CSS واقعیِ همین نسخه):
   preview/credits.html را با مرورگر باز کنید (لازم به نصب روی هاست نیست)

بازگشت: rollback-v3.2.3.zip → دو فایل .3.2.2 را جایگزین کنید.
