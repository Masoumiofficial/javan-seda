نسخۀ 3.3.2 — «متن آهنگ» زیر لینک‌های دانلود (روی 3.3.1؛ همان شیشه/تراز هم داخلش است)
============================================================================

ساختار zip همان wp-content/themes/javanseda است:
   جایگزین: style.css · single.php · inc/theme-options.php · 404.php · myfunctions.php
   اضافه : inc/ab-glass.php · css/ab-glass.css

کمینۀ ممکن برای فقط همین تغییر جابه‌جایی (بدون شیشه/تراز 3.3.x):
   single.php + inc/theme-options.php + style.css   (سه فایل)

بازگشت تنظیمی بدون ویرایش فایل:
   پیشخوان → نمایش → تنظیمات قالب → «صفحۀ دانلود آهنگ» → «متن ترانه زیر لینک دانلود» = خاموش
خاموشی‌های بقیۀ لایه‌ها:
   define('JAVANSEDA_GLASS_UI', false);   // لایۀ شیشه
   define('JAVANSEDA_GLASS_BLUR', false); // تارکردگی
بازگشت فایل: rollback-v3.3.2.zip (نسخۀ 3.3.1 همین سه فایل) · برای 3.2.4 هم rollback-v3.3.1.zip

پیش‌نمایش: preview/glass-ui.html (CSS و ترتیب واقعی همین نسخۀ مخزن)
