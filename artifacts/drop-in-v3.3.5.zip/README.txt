javanseda v3.3.5 — پچِ سه‌فایلی
--------------------------------
این فایل‌ها را در wp-content/themes/javanseda/ بریزید و جایگزین کنید:
  style.css            -> wp-content/themes/javanseda/style.css
  css/ab-glass.css     -> wp-content/themes/javanseda/css/ab-glass.css
  category.php         -> wp-content/themes/javanseda/category.php

چه چیزهایی درست می‌شود:
  1) بریدگی عنوان صفحۀ دسته با «…» (حالا تا دو خط می‌شکند)
  2) «کادر سفید خالی» زیر عنوان دسته وقتی توضیح دسته خالی است
  3) چسبیدن دایره‌های ریل هنرمندان به هم + کج‌شدن ردیف با نام بلند
  4) حلقۀ فوکوس کیبورد که لبۀ کارت‌ها بریده می‌شد
  5) کارت سفیدِ باکس شبکه‌های اجتماعی و شبرنگ‌های شناسنامه در حالت شب

اگر فقط style.css و css/ab-glass.css را بگذارید هم مورد ۱ تا ۵ درست می‌شود؛
category.php فقط همان divِ بی‌محتوا را از HTML برمی‌دارد (تأثیر بصری ندارد).
بعد از آپلود: Ctrl+F5 و اگر افزونۀ کش دارید، یک پاک‌سازی.
بازگشت: rollback-v3.3.5.zip
