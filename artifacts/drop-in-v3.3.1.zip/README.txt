نسخۀ 3.3.1 (جایگزین 3.3.0) — رابط شیشه‌ای + رفع ریشۀ تراز + پچ two !important
==============================================================================

ساختار zip همان wp-content/themes/javanseda است؛ پنج فایل (سه جایگزین، دو اضافه):
   style.css  404.php  myfunctions.php            -> جایگزین
   inc/ab-glass.php  css/ab-glass.css             -> اضافه

پچ 3.3.1: .night #header و .ab-quickbar در style.css توکنی شدند تا لایۀ شیشه
واقعاً به آن‌ها برسد؛ با JAVANSEDA_GLASS_UI=false همان مقادیر 3.2.4 برمی‌گردد.

خاموشی:
   define('JAVANSEDA_GLASS_UI', false);    // کل لایۀ شیشه (تراز و ساختار می‌ماند)
   define('JAVANSEDA_GLASS_BLUR', false);  // سطوح نیمه‌شفاف بدون تارکردگی
بازگشت به 3.2.4: rollback-v3.3.1.zip

پیش‌نمایش: preview/glass-ui.html (CSS واقعی همین نسخۀ مخزن)
