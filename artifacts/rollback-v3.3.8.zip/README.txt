بازگشت از 3.3.8 به 3.3.7
========================

هر فایل با همان مسیر نسبی داخل wp-content/themes/javanseda/ برود و پسوند .3.3.7 از
نامش حذف شود:
    style.css.3.3.7   →  style.css
    inc/ab-perf.php.3.3.7  →  inc/ab-perf.php   …

سه فایل/پوشۀ اینها «جدیدِ 3.3.8» بودند و در 3.3.7 وجود نداشتند؛ برای بازگشت کامل
حذفشان کنید (اگر نمانند هم هیچ خطایی نمی‌دهید، چون include با is_readable است):
    css/ab-ui.css
    inc/ab-ui-guard.php
    fonts/*.woff2

پس از بازگشت: Hard Refresh + (اگر theme_mods/کش ندارید) یک‌بار بررسی / و صفحۀ آهنگ.
