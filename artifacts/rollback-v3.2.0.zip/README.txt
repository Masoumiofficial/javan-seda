بازگشت از 3.2.0 به 3.1.4

1) فایل‌های زیر را (پسوند .3.1.4 را بردارید) در wp-content/themes/javanseda جایگزین کنید:
     footer.php · single.php · style.css · myfunctions.php · inc/theme-options.php
2) فایل wp-content/themes/javanseda/inc/ab-post-extras.php را حذف کنید (در 3.1.4 وجود نداشت).
3) تنظیمات قالب را دست نزنید؛ فیلدهای بله/روبیکا بی‌استفاده می‌مانند و هیچ خطایی نمی‌سازند.

نسخۀ کامل و دست‌نخورۀ 3.1.4 هم در drop-in-v3.1.4.zip داخل همین فایل است.
