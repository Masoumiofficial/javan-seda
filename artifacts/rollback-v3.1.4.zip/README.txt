بستۀ بازگردانی — نسخۀ 3.1.4
=================================
ساده‌ترین بازگشت از «لایۀ دیده‌شدن» (v3.1.4) — بی‌خطر:
  1) rm wp-content/themes/javanseda/inc/ab-seo.php     (نبودش هیچ‌چیز را نمی‌شکند)
  2) در myfunctions.php بلوک زیر را بردارید (یا فایل را از همین پوشه برگردانید):
       $_javan_seda_seo = trailingslashit( get_template_directory() ) . 'inc/ab-seo.php';
       if ( is_readable( $_javan_seda_seo ) ) { require_once $_javan_seda_seo; }
  3) اگر 404.php / search.php / home.php / inc/songs_post.php / inc/tarlanweb_player.php را
     عوض کردید: نسخۀ 3.1.3 همین فایل‌ها در این پوشه است (پسوند .3.1.3).
  4) Purge All (افزونۀ کش) + Purge CDN
نسخۀ 3.1.3 این فایل‌ها هم اینجاست:
  header.php.3.1.3
  style.css.3.1.3
  myfunctions.php.3.1.3
  home.php.3.1.3
  single.php.3.1.3
  ab-mobile-probe.php.3.1.3
  ab-sidebars.php.3.1.3
  404.php.3.1.3
  search.php.3.1.3
  songs_post.php.3.1.3
  tarlanweb_player.php.3.1.3
  ab-perf.php.3.1.3
  ab-news-ticker.php.3.1.3
نکته: home.php در 3.1.4 فقط ۸ سطر اولش اضافه شده؛ اگر خواستید همان ۸ سطر را پاک کنید،
بقیۀ فایل دست‌نخورده می‌ماند (ساده‌ترین راه بازگشتِ «صفحۀ تکراری»).
برای بستن کل دورهای 3.1.x: drop-in-v3.1.3.zip (قبل از این دور) یا در بستۀ قبل header.php.original
