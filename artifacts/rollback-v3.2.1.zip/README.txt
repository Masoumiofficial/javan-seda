بازگشت از 3.2.1 به 3.2.0

1) فایل‌های با پسوند .3.2.0 را (پسوند را بردارید) در wp-content/themes/javanseda جایگزین کنید:
     single.php · myfunctions.php · style.css · inc/theme-options.php
2) فایل wp-content/themes/javanseda/inc/ab-credits.php را حذف کنید (در 3.2.0 وجود نداشت).
3) مقادیر واردشده در postmeta بی‌ضرر می‌مانند؛ برای پاک کردنشان:
     wp db query "DELETE FROM wp_postmeta WHERE meta_key IN ('composer','lyricist','arranger','mixer','producer')"
4) راه سریع‌ترِ خاموش‌کردن بدون بازگشت فایل‌ها: define('JAVANSEDA_CREDITS', false) در wp-config.php

نسخۀ کامل 3.2.0 داخل همین فایل: drop-in-v3.2.0.zip
