بازگشت از 3.3.3 به 3.3.2
============================
سه فایلِ تغییرکرده را با هم‌نامِ .3.3.2 داخل همین زیپ جایگزین کنید (پسوند را بردارید):
   style.css · ab-glass.css (به پوشۀ css/) · mobiles_header.php (به پوشۀ inc/)

سریع‌تر (فقط ۴۰۴/شیشه): define('JAVANSEDA_GLASS_UI', false) در wp-config.php
بازگشت تا 3.2.4: artifacts/rollback-v3.3.1.zip · تا 3.3.1: rollback-v3.3.2.zip
