نسخۀ 3.2.2 — دیدِ بهترِ صفحۀ پست (schema برای همهٔ نوشته‌ها + رفع تکراری با افزونۀ سئو + رفع مین‌های PHP)
روی 3.2.1 نصب می‌شود. فایل تازه‌ای ندارد؛ فقط پنج فایل جایگزین می‌شوند:
  inc/ab-credits.php · inc/ab-seo.php · inc/ab-perf.php · single.php · style.css

اگر 3.2.1 را نصب نکرده‌اید: inc/ab-credits.php را از برچسب v3.2.1 بگیرید (این دور همان فایل را گسترش داده است)
  https://github.com/Masoumiofficial/javan-seda/raw/refs/tags/v3.2.1/drop-in/inc/ab-credits.php
یا کل 3.2.2 را از همین زیپ بردارید و همۀ فایل‌های other/ را جایگزین کنید.

بازگشت: rollback-v3.2.2.zip → فایل‌های .3.2.1 را جایگزین کنید.
خاموشی سریع بدون بازگشت فایل:
  define('JAVANSEDA_MUSIC_SCHEMA', false);          → فقط JSON-LD موسیقی
  define('JAVANSEDA_SEO_OVERRIDE_PLUGIN', true);    → لایه با وجود افزونۀ سئو هم meta/OG را چاپ کند
