javanseda v3.3.5 -> v3.3.4 (بازگشت)
سه فایلِ همین زیپ را با نام‌های زیر در wp-content/themes/javanseda/ جایگزین کنید:
  style.css.3.3.4        -> style.css
  css/ab-glass.css.3.3.4 -> css/ab-glass.css
  category.php.3.3.4     -> category.php
