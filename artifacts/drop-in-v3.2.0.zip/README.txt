نسخۀ 3.2.0 — قابل جایگزینی روی 3.1.4 (بهترین روش: File Manager → دانلود → جایگزینی)
ساختار zip:
  new/ab-post-extras.php      ->  wp-content/themes/javanseda/inc/ab-post-extras.php   (فایل تازه)
  other/footer.php            ->  wp-content/themes/javanseda/footer.php
  other/single.php            ->  wp-content/themes/javanseda/single.php
  other/style.css             ->  wp-content/themes/javanseda/style.css
  other/myfunctions.php       ->  wp-content/themes/javanseda/myfunctions.php
  other/inc/theme-options.php ->  wp-content/themes/javanseda/inc/theme-options.php

قدم‌ها:
  1) فایل new/ab-post-extras.php را در پوشۀ inc قالب کپی کنید.
  2) چهار/پنج فایل پوشۀ other را با فایل هم‌نام خودِ قالب جایگزین کنید.
  3) پیشخوان → تنظیمات قالب → «شبکه‌های اجتماعی»: لینک بله و روبیکا را پر کنید،
     متن دکمه‌ها را بنویسید و گزینهٔ «باکس شبکه‌های اجتماعی در صفحهٔ پست» را روشن بگذارید.
  4) کش (کش سرور/ افزونۀ کش / CDN) را خالی کنید و یک صفحۀ پست را باز کنید.

اگر فایل new/ab-post-extras.php نصب نشود، بقیهٔ فایل‌ها هم هیچ خطایی نمی‌دهند:
  single.php با function_exists محافظت شده و footer.php فقط یک بلوک کامنت جایگزین باکس شناور کرده است.

بازگشت به 3.1.4: rollback-v3.2.0.zip → فایل‌های .3.1.4 را جایگزین کنید و inc/ab-post-extras.php را حذف کنید.
