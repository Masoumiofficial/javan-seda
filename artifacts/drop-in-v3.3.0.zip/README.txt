نسخۀ 3.3.0 — رابط شیشه‌ای + تراز سراسری (صفحة اصلی · نوشته تکی · ۴۰۴)
=====================================================================

ساختار پوشهٔ zip همان ساختار wp-content/themes/javanseda است؛ پنج فایل را جایگزین/اضافه کنید:
   style.css            ->  (جایگزین)  wp-content/themes/javanseda/style.css
   404.php              ->  (جایگزین)  wp-content/themes/javanseda/404.php
   myfunctions.php      ->  (جایگزین)  wp-content/themes/javanseda/myfunctions.php
   inc/ab-glass.php     ->  (اضافه)    wp-content/themes/javanseda/inc/ab-glass.php
   css/ab-glass.css     ->  (اضافه)    wp-content/themes/javanseda/css/ab-glass.css

هیچ افزونه، هیچ تغییر دیتابیس، هیچ فایل تصویر/فونت/JS تازه.

خاموشی:
   define('JAVANSEDA_GLASS_UI', false);    // کل لایۀ شیشه (تراز و ساختار می‌ماند)
   define('JAVANSEDA_GLASS_BLUR', false);  // سطوح نیمه‌شفاف بدون تارکردگی
حذف کامل 3.3.0: rollback-v3.3.0.zip (دو فایل جدید هم می‌توانند بمانند؛ بی‌اثر می‌شوند)

پیش از نصب، دمو را ببینید: preview/glass-ui.html (با CSS واقعی همین نسخۀ مخزن)
