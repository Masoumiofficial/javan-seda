جوان‌صدا ۳.۵.۲ — drop-in (فقط فایل‌های تغییرکرده/تازه)
======================================================
۱۴ فایل. دو فایلِ لایسنس (functions.php و RTL_License_41d6c5f704e3a746.php) عمداً در این
بسته نیستند: لایسنسِ روی سرور شما باید دست‌نخورده بماند.

نصب: محتوای بسته را در wp-content/themes/javanseda/ باز کنید (Extract/Overwrite).
سپس Purge All در افزونهٔ کش. style.css باید Version: 3.5.2 بدهد.

برای نصبِ کامل، javanseda-3.5.2.zip را با File Manager در wp-content/themes/ باز کنید.
