جوان‌سدا — نسخۀ 3.4.7 (drop-in) · یکدست‌سازی «هنرمند»: تاکسونومی singer → artist
================================================================================

هفده فایل (یک فایل تازه + یک تمپلیت بازنامیده‌شده). پیش‌نیاز: 3.4.6.

چرا
--------------------------------------------------------------------------------
  برای یک مفهوم دو نام داشتید: تاکسونومی خواننده‌ها «singer» (ثبت مادر، آرشیو
  /singer/slug) و همه‌جای دیگر «artist» (فیلد ACFِ artist، کلاس‌های ab-artist__*،
  فایل artist-template.php). این دوگانگی منبع باگ است.

چه کار می‌کند
--------------------------------------------------------------------------------
  · هلپرهای تازه در inc/ab-tax-artist.php:
      javan_seda_artist_tax()        نامک فعال (artist / singer)
      javan_seda_artist_slug()       آدرس آرشیو (پیش‌فرض artist)
      javan_seda_artist_term_link()  لینک ترم، با فالبکِ آدرس‌ساز (href خالی نمی‌سازد)
      javan_seda_artists_index_url() صفحۀ «همهٔ هنرمندان»: اسلاگ artists ← artist ← singers
  · مهاجرت: فقط یک ستون — wp_term_taxonomy.taxonomy از singer به artist.
    term_id، رابطه‌ها، termmeta، شمارش و اسلاگ‌ها دست نمی‌خورند. با کلیدِ خاموش،
    همان UPDATE برعکس می‌شود (SQL دستی لازم نیست).
  · آرگومان‌های ثبت از خودِ تاکسونومیِ مادر برداشته می‌شود (public/show_ui/
    show_in_rest/query_var/hierarchical)؛ فقط نامک، برچسب‌ها و rewrite عوض می‌شود.
  · singer به‌صورت تاکسونومیِ پنهانِ بدونِ آدرس باقی می‌ماند تا خواندن‌های کد
    رمزنگاری‌شدۀ مادر به خطا نیفتد.
  · /singer/<slug> با 301 به /artist/<slug> (صفحه‌بندی و query string حفظ).
  · taxonomy-singer.php → taxonomy-artist.php (یک شیم کوچک جایش ماند؛ هر دو کار می‌کنند).

  اگر inc/ab-tax-artist.php نباشد، فالبک‌های هم‌نام در myfunctions.php همه‌چیز را
  دقیقاً مثل قبل (singer) نگه می‌دارند. هیچ فایلی تنها نمی‌شکند.

تنظیم
--------------------------------------------------------------------------------
  «مظهر ← تنظیمات پوسته ← کنترل رابط ← نامک «هنرمند»»:
    · نامک artist فعال باشد   (on-off، پیش‌فرض روشن)
    · آدرسِ آرشیو هنرمند      (متن، پیش‌فرض artist)
  خاموشی کامل:  define( 'JAVANSEDA_ARTIST_TAX', false );  در wp-config.php

فایل‌ها
--------------------------------------------------------------------------------
  inc/ab-tax-artist.php         19,959 B
  myfunctions.php               33,894 B
  single.php                    40,040 B
  taxonomy-artist.php           32,736 B
  taxonomy-singer.php              928 B
  inc/ab-credits.php            29,450 B
  inc/ab-seo.php                24,391 B
  inc/theme-options.php         31,902 B
  inc/ab-controls.php           13,018 B
  inc/mobiles_header.php         4,667 B
  artist-template.php           37,054 B
  home.php                       4,046 B
  footer.php                    10,025 B
  404.php                        4,232 B
  inc/ab-sidebars.php           23,008 B
  style.css                    196,785 B
  css/ab-ui.css                 86,665 B

نصب — به همین ترتیب
--------------------------------------------------------------------------------
  1) بکاپ از یک جدول:  mysqldump -u USER -p DBNAME wp_term_taxonomy > term_taxonomy.sql
  2) فایل‌ها را در wp-content/themes/javanseda/ بریزید (پوشه‌های inc/ و css/ را باز کنید).
  3) «تنظیمات پوسته ← کنترل رابط» را باز کنید و «ذخیرۀ تغییرات» را بزنید.
  4) لازم: «تنظیمات ← پیوندهای یکتا ← ذخیره» (یک بار). اگر لینک هنرمند ۴۰۴ شد، همین کار را بکنید.
  5) گزارش:  https://ahangban.ir/?ab_artist_diag=1   ⇒  «نامک فعال: artist | تعداد اصطلاح: N»
     و باز کردن یک /artist/<slug>/ و یک /singer/<slug>/ (دومی باید ۳۰۱ بخورد).
  6) صحت‌سنجی نسخۀ فایل‌ها:
     https://ahangban.ir/wp-content/themes/javanseda/style.css?v=check347  →  Version: 3.4.7

اختیاری: اگر می‌خواهید صفحۀ فهرست هم /artists/ شود، در پیشخوان اسلاگِ برگه را از
singers به artists عوض کنید؛ کد هر دو را می‌شناسد و هیچ لینکی نمی‌شکند.

بازگشت
--------------------------------------------------------------------------------
  «نامک artist فعال باشد» = خاموش + ذخیره (مهاجرت برعکس می‌شود)
  یا فایل‌های rollback-v3.4.7.zip (پسوند .3.4.6 را حذف کنید).
