بستهٔ بازگردانی — نسخهٔ 3.1.2
============================
ساده‌ترین بازگشت (بی‌خطر): حذف فایل‌های افزودهٔ ما — قالب بدون آن‌ها هم کار می‌کند
  rm wp-content/themes/javanseda/inc/ab-news-ticker.php     (نوار اخبار روز)
  rm wp-content/themes/javanseda/inc/acf-compat.php         (سازگاری ACF)
  rm wp-content/themes/javanseda/inc/ab-sidebars.php        (لایهٔ ایمنی سایدبار)
  rm wp-content/themes/javanseda/ab-mobile-probe.php       (کاوشگر؛ همیشه پاک شود)
و سپس بازگرداندن home.php / myfunctions.php / header.php / style.css به نسخهٔ قبل:
  header.php.3.0.5 / style.css.3.0.5      ← همین پوشه (نسخهٔ ۳.۰.۵)
  drop-in-v3.1.1.zip                       ← بستهٔ قبلی (برای single.php / page.php / home.php)
  ab-sidebars-3.1.x-minimal.php            ← لایهٔ ایمنی کمینۀ ۳.۱.x (بدون فیلتر the_content)

برای بازگشتِ «اخبار روز» به «نوار دسترسی سریع ۳.۰.۱»: در home.php کافی است خط
  javan_seda_news_ticker();
را کامنت کنید — fallbackِ همان فایل، نوار قدیمی را چاپ می‌کند.
پس از هر بازگردانی: Purge All در افزونهٔ کش + CDN.
