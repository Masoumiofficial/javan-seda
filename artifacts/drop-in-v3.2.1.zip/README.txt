نسخۀ 3.2.1 — «شناسنامۀ آهنگ» (آهنگساز · ترانه‌سرا · تنظیم · میکس و مستر · تولید)
روی نسخۀ 3.2.0 نصب می‌شود (اگر 3.2.0 را نصب نکرده‌اید، drop-in-v3.2.0.zip را هم بگیرید).

ساختار zip:
  new/ab-credits.php              ->  wp-content/themes/javanseda/inc/ab-credits.php     (فایل تازه)
  other/single.php                ->  wp-content/themes/javanseda/single.php
  other/myfunctions.php           ->  wp-content/themes/javanseda/myfunctions.php
  other/inc/theme-options.php     ->  wp-content/themes/javanseda/inc/theme-options.php
  other/style.css                 ->  wp-content/themes/javanseda/style.css

قدم‌ها:
  1) فایل new/ab-credits.php را در پوشۀ inc قالب کپی کنید.
  2) چهار فایل other را با فایل هم‌نام خودِ قالب جایگزین کنید.
  3) هر نوشته را باز کنید و در کادر «شناسنامۀ آهنگ (تهیه‌کنندگان)» نام‌ها را پر کنید.
     کلیدها: composer · lyricist · arranger · mixer · producer (خواننده از artist یا ترم singer می‌آید)
  4) تنظیمات قالب → صفحه دانلود آهنگ → «شناسنامۀ آهنگ» / «تیتر باکس…» / «شناسنامه بالای پلیر».
  5) کش را خالی کنید.

بی‌خطر: اگر فایل new/ab-credits.php نصب نشود، بقیۀ فایل‌ها هیچ خطایی نمی‌دهند (فراخوان‌ها function_exists هستند).
بازگشت: rollback-v3.2.1.zip → نسخۀ 3.2.0 همان فایل‌ها را جایگزین و inc/ab-credits.php را حذف کنید.
