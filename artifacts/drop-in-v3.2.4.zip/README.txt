نسخۀ 3.2.4 — نوار چسبانِ پخش: تیره در حالت شب، کوتاه‌تر، قبلی/بعدی، پخش روی صفحۀ اصلی

دو فایل را جایگزین کنید (فایل تازه‌ای لازم نیست؛ دیتابیس دست نمی‌خورد):
   inc/ab-post-extras.php  ->  wp-content/themes/javanseda/inc/ab-post-extras.php
   style.css                ->  wp-content/themes/javanseda/style.css

پیش‌نمایش محلیِ همان ظاهر: preview/sticky-player.html (لازم به نصب نیست)
خاموشی‌ها در wp-config.php:
   define('JAVANSEDA_STICKY_PLAYER', false);   // کل نوار
   define('JAVANSEDA_STICKY_ON_HOME', false);  // فقط صفحۀ اصلی
   define('JAVANSEDA_STICKY_HOME_LIMIT', 5);   // تعداد آهنگ صفحۀ اصلی

بازگشت: rollback-v3.2.4.zip → دو فایل .3.2.3 را جایگزین کنید.
