نسخۀ 3.3.3 — ریل لمسی موبایل · رفع کشوی منو · دیدگاه‌ها · ۴۰۴ در حالت روشن
=====================================================================

ساختار zip همان wp-content/themes/javanseda است (هشت فایل):
   جایگزین: style.css · css/ab-glass.css · inc/ab-glass.php · inc/mobiles_header.php
            single.php · inc/theme-options.php · 404.php · myfunctions.php
اگر 3.3.2 را نصب کرده‌اید، برای این نسخه فقط سه فایل لازم است:
   style.css · css/ab-glass.css · inc/mobiles_header.php

هیچ افزونه/JS/گرادینت/تصویر تازه، هیچ تغییر دیتابیس.
خاموشی‌ها:
   define('JAVANSEDA_GLASS_UI', false);    // لایۀ شیشه (ریل/دیدگاه/۴۰۴/کشی درست می‌مانند)
   define('JAVANSEDA_GLASS_BLUR', false);  // بدون تارکردگی
   تنظیمات قالب → «متن ترانه زیر لینک دانلود» = خاموش ⇒ بازگشت متن آهنگ به جای قبلی
بازگشت فایل: rollback-v3.3.3.zip (نسخۀ 3.3.2 سه فایل)

پیش‌نمایش: preview/glass-ui.html — پنجره را زیر ۷۶۸px بیاورید
