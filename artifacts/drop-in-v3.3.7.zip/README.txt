javanseda v3.3.7 — پچِ سه‌فایلی (CSS + یک تمپلیت کارت)
----------------------------------------------------
  style.css              -> wp-content/themes/javanseda/style.css
  css/ab-glass.css       -> wp-content/themes/javanseda/css/ab-glass.css
  inc/songs_post.php     -> wp-content/themes/javanseda/inc/songs_post.php

درست/اضافه می‌شود:
  1) «محبوبترین هنرمندان»: دایره از کادر مربعی/مستطیلی بیرون آمد. علت: در ab-glass.css
     قاعدۀ کارت (border-radius + border + box-shadow + background) گزينۀ .artist_boxs a هم داشت؛
     حالا آن گزينه برداشته شده و آیتم هنرمند فقط همان دایره است (در hover حلقه آبی می‌گیرد).
  2) کارآمارِ روی کاور هر آهنگ: تعداد بازدید (متای views) و میانگین رأی (kksr_avg یا
     kksr_ratings ÷ kksr_casts) با ستاره. دسکتاپ: با اشاره/فوکوس، کاور مات‌وشیشه‌ای می‌شود و
     دو چیپ بالا می‌آیند. موبایل: بدون فیلتر، چیپ‌ها همیشه روی پایین کاور (خوانا و بی‌هزینه).
     صفر JS، صفر کوئری اضافه، صفر تغییر چیدمان (absolute داخل figure).
  3) اگر هیچ عددی ثبت نشده باشد هیچ کارایی چاپ نمی‌شود.

خاموشی:  define('JAVANSEDA_CARD_STATS', false);   در wp-config.php
         (یا add_filter('javanseda_card_stats','__return_false'); در functions.php)
رنگ ستاره: پیش‌فرض آبی برند است؛ برای طلایی — :root{--ab-cs-star:#FFC93C}
روی اسلایدر VIP هم می‌خواهید؟ داخل figure در inc/vip_slider.php یک خط:
         <?php javan_seda_card_stats(); ?>

بعد از آپلود: Ctrl+F5 (و پاک‌سازی کش اگر افزونه دارید).
بازگشت: rollback-v3.3.7.zip — سه فایلِ همین زیپ با پسوند .3.3.6 را هم‌نام کنید.
